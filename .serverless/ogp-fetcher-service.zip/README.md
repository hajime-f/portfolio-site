# Fujita, Hajime
